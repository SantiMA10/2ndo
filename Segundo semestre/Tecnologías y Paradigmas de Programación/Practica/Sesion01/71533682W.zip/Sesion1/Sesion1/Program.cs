﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sesion1
{
    /// <summary>
    ///     Ejemplo Hola Mundo
    /// </summary>
    class Program
    {
        /// <summary>
        ///     Método principal de el primer ejemplo en C#
        /// </summary>
        /// <param name="args">Serian los parametros que se le pasarian al método main
        ///     [0] Lo que sea...
        ///     [1] Otra vez lo que sea....
        /// </param>
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hola mundo!!!");
        }
    }
}
